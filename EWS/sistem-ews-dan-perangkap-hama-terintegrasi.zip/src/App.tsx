/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  EWSNode,
  PestTrapNode,
  AlarmLog,
  UserAccount,
  TelegramConfig,
} from './types';
import {
  INITIAL_USERS,
  INITIAL_EWS_NODES,
  INITIAL_PEST_TRAPS,
  INITIAL_ALARM_LOGS,
} from './mockData';
import { LoginModal } from './components/LoginModal';
import { Navbar } from './components/Navbar';
import { OverviewAllEWS } from './components/OverviewAllEWS';
import { EWSDashboardSingle } from './components/EWSDashboardSingle';
import { PestTrapDashboard } from './components/PestTrapDashboard';
import { AlarmHistoryView } from './components/AlarmHistoryView';
import { EngineeringDocsModal } from './components/EngineeringDocsModal';
import { SimulationControls } from './components/SimulationControls';
import { TelegramConfigModal } from './components/TelegramConfigModal';
import { Volume2, VolumeX, ShieldAlert, Radio, Send, Bell } from 'lucide-react';

export default function App() {
  // Authentication: starts at null so login page is displayed before dashboard
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  
  // Navigation tab: 'overview', 'EWS-01', 'EWS-02', 'EWS-03', 'EWS-04', 'pest-traps', 'alarm-history'
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Application Data States
  const [ewsNodes, setEwsNodes] = useState<EWSNode[]>(INITIAL_EWS_NODES);
  const [pestTraps, setPestTraps] = useState<PestTrapNode[]>(INITIAL_PEST_TRAPS);
  const [alarmLogs, setAlarmLogs] = useState<AlarmLog[]>(INITIAL_ALARM_LOGS);

  // Modals & UI States
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [editingTelegramEws, setEditingTelegramEws] = useState<EWSNode | null>(null);
  const [globalMute, setGlobalMute] = useState(false);

  // Audio synthesizer ref for simulated local 12V 110dB siren
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Handle Login
  const handleLogin = (user: UserAccount) => {
    setCurrentUser(user);
    // If operator, default directly to their dedicated EWS dashboard!
    if (user.role.startsWith('operator_') && user.assignedEwsId) {
      setActiveTab(user.assignedEwsId);
    } else {
      setActiveTab('overview');
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab('overview');
  };

  // Update specific EWS
  const handleUpdateEws = (updated: EWSNode) => {
    setEwsNodes((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
  };

  // Update specific Pest Trap
  const handleUpdateTrap = (updated: PestTrapNode) => {
    setPestTraps((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  };

  // Trigger Local Siren / Alarm
  const handleTriggerAlarm = (ewsId: string, type: 'siaga' | 'bahaya') => {
    setEwsNodes((prev) =>
      prev.map((e) => {
        if (e.id === ewsId) {
          return {
            ...e,
            status: type,
            sirenActive: type === 'bahaya',
            stroboActive: true,
          };
        }
        return e;
      })
    );
  };

  // Reset Alarm
  const handleResetAlarm = (ewsId: string) => {
    setEwsNodes((prev) =>
      prev.map((e) => {
        if (e.id === ewsId) {
          return {
            ...e,
            status: 'aman',
            sirenActive: false,
            stroboActive: false,
            muted: false,
            sensorData: {
              ...e.sensorData,
              pitchAngle: 0.15,
              rollAngle: -0.05,
              rainfallRate: 0.0,
            },
          };
        }
        return e;
      })
    );
  };

  // Simulation Scenarios
  const handleTriggerScenario = (
    ewsId: string,
    scenario: 'siaga' | 'bahaya' | 'offline' | 'baterai_lemah' | 'reset'
  ) => {
    setEwsNodes((prev) =>
      prev.map((e) => {
        if (e.id !== ewsId) return e;

        if (scenario === 'bahaya') {
          // Add alarm log
          const newLog: AlarmLog = {
            id: `ALM-${Date.now().toString().slice(-4)}`,
            ewsId: e.id,
            ewsName: e.name,
            timestamp: new Date().toLocaleString('id-ID') + ' WIB',
            type: 'bahaya',
            triggerCause: 'Kemiringan Tanah Ekstrem (Inclinometer) & Getaran ADXL345',
            triggerValue: `Pitch: 3.42° (Ambang: ${e.thresholds.tiltDanger}°) | Getaran: 0.38g`,
            durationMinutes: 1,
            acknowledged: false,
          };
          setAlarmLogs((oldLogs) => [newLog, ...oldLogs]);

          return {
            ...e,
            status: 'bahaya',
            sirenActive: true,
            stroboActive: true,
            sensorData: {
              ...e.sensorData,
              pitchAngle: 3.42,
              rollAngle: 1.88,
              rainfallRate: 58.2,
              soilMoisture: 84.5,
              vibrationLevel: 0.38,
            },
          };
        } else if (scenario === 'siaga') {
          const newLog: AlarmLog = {
            id: `ALM-${Date.now().toString().slice(-4)}`,
            ewsId: e.id,
            ewsName: e.name,
            timestamp: new Date().toLocaleString('id-ID') + ' WIB',
            type: 'siaga',
            triggerCause: 'Curah Hujan Tinggi & Pergeseran Sudut Awal',
            triggerValue: `Hujan: 32.4 mm/jam | Pitch: 1.65°`,
            durationMinutes: 1,
            acknowledged: false,
          };
          setAlarmLogs((oldLogs) => [newLog, ...oldLogs]);

          return {
            ...e,
            status: 'siaga',
            sirenActive: false,
            stroboActive: true,
            sensorData: {
              ...e.sensorData,
              pitchAngle: 1.65,
              rainfallRate: 32.4,
              soilMoisture: 76.0,
            },
          };
        } else if (scenario === 'offline') {
          return {
            ...e,
            status: 'offline',
            sensorData: {
              ...e.sensorData,
              gsmStatus: 'offline',
              gsmSignalDbm: -115,
            },
          };
        } else if (scenario === 'baterai_lemah') {
          return {
            ...e,
            status: 'baterai_lemah',
            sensorData: {
              ...e.sensorData,
              batteryVoltage: 11.2,
              solarCurrent: 120,
            },
          };
        } else {
          // Reset
          return {
            ...e,
            status: 'aman',
            sirenActive: false,
            stroboActive: false,
            muted: false,
            sensorData: {
              ...e.sensorData,
              pitchAngle: 0.12,
              rollAngle: -0.06,
              soilMoisture: 42.0,
              rainfallRate: 0.0,
              vibrationLevel: 0.02,
              batteryVoltage: 12.8,
              gsmStatus: 'online',
              gsmSignalDbm: -68,
            },
          };
        }
      })
    );
  };

  // Acknowledge Alarm Log
  const handleAcknowledgeLog = (logId: string, note: string, author: string) => {
    setAlarmLogs((prev) =>
      prev.map((log) => {
        if (log.id === logId) {
          return {
            ...log,
            acknowledged: true,
            acknowledgedBy: author,
            acknowledgeNote: note,
            acknowledgedAt: new Date().toLocaleString('id-ID') + ' WIB',
          };
        }
        return log;
      })
    );
  };

  // Check if any siren is currently blaring
  const anySirenActive = ewsNodes.some((e) => e.sirenActive && !e.muted && !globalMute);
  const activeSirenNodes = ewsNodes.filter((e) => e.sirenActive);

  // Sound effect trigger for 12V 110dB siren simulation
  useEffect(() => {
    if (!anySirenActive) {
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
        audioCtxRef.current = null;
      }
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioCtxRef.current = ctx;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(1400, ctx.currentTime + 0.3);
      osc.frequency.linearRampToValueAtTime(800, ctx.currentTime + 0.6);

      // Low volume for safety
      gain.gain.setValueAtTime(0.08, ctx.currentTime);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      const timer = setInterval(() => {
        if (ctx.state === 'running') {
          osc.frequency.setValueAtTime(800, ctx.currentTime);
          osc.frequency.linearRampToValueAtTime(1400, ctx.currentTime + 0.3);
          osc.frequency.linearRampToValueAtTime(800, ctx.currentTime + 0.6);
        }
      }, 600);

      return () => {
        clearInterval(timer);
        osc.stop();
        ctx.close().catch(() => {});
      };
    } catch {
      // Audio context might be restricted before user gesture
    }
  }, [anySirenActive]);

  // Selected EWS for single dashboard view
  const currentEws = ewsNodes.find((e) => e.id === activeTab);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* 1. Login Modal - shown prior to accessing dashboard */}
      {!currentUser && <LoginModal onLogin={handleLogin} />}

      {/* Main Authenticated Dashboard */}
      {currentUser && (
        <>
          {/* Navbar */}
          <Navbar
            currentUser={currentUser}
            activeTab={activeTab}
            onSelectTab={setActiveTab}
            onLogout={handleLogout}
            onOpenDocs={() => setIsDocsOpen(true)}
            ewsNodes={ewsNodes}
          />

          {/* Active Siren Banner (Page 3 & 6 of Document) */}
          {activeSirenNodes.length > 0 && (
            <div className="bg-red-600 text-white px-4 py-3 flex items-center justify-between shadow-xl animate-pulse sticky top-16 z-30">
              <div className="flex items-center gap-3">
                <ShieldAlert className="w-5 h-5 shrink-0" />
                <div className="text-xs sm:text-sm font-bold">
                  PERINGATAN BAHAYA: Sirine Lokal 12V 110dB &amp; Lampu Strobo Aktif di{' '}
                  {activeSirenNodes.map((e) => e.name).join(', ')}!
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setGlobalMute(!globalMute)}
                  className="px-3 py-1 bg-red-950/80 hover:bg-red-900 border border-red-300/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  {globalMute ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span>{globalMute ? 'Unmute Audio' : 'Mute Sirine Audio'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Main Content Container */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
            
            {/* Simulation controls for acceptance testing */}
            <SimulationControls
              ewsNodes={ewsNodes}
              onTriggerScenario={handleTriggerScenario}
            />

            {/* View Switching */}
            {activeTab === 'overview' && (
              <OverviewAllEWS
                ewsNodes={ewsNodes}
                pestTraps={pestTraps}
                onSelectEws={(ewsId) => setActiveTab(ewsId)}
                onOpenTelegramConfig={(ews) => setEditingTelegramEws(ews)}
              />
            )}

            {currentEws && (
              <EWSDashboardSingle
                key={currentEws.id}
                ews={currentEws}
                currentUser={currentUser}
                onUpdateEws={handleUpdateEws}
                onTriggerAlarm={handleTriggerAlarm}
                onResetAlarm={handleResetAlarm}
              />
            )}

            {activeTab === 'pest-traps' && (
              <PestTrapDashboard
                traps={pestTraps}
                onUpdateTrap={handleUpdateTrap}
              />
            )}

            {activeTab === 'alarm-history' && (
              <AlarmHistoryView
                logs={alarmLogs}
                currentUser={currentUser}
                onAcknowledgeLog={handleAcknowledgeLog}
              />
            )}
          </main>

          {/* Footer */}
          <footer className="border-t border-slate-800 bg-slate-950 py-6 text-xs text-slate-500">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-slate-400">
                  Sistem EWS dan Perangkap Hama Terintegrasi
                </p>
                <p className="text-[11px] text-slate-500">
                  4 Titik Landslide Early Warning System &bull; 5 Unit Perangkap Hama Bertenaga Surya 30Wp
                </p>
              </div>

              <div className="flex items-center gap-4 text-[11px]">
                <button
                  onClick={() => setIsDocsOpen(true)}
                  className="hover:text-cyan-400 underline cursor-pointer"
                >
                  Spesifikasi Teknis &amp; Fabrikasi 3D
                </button>
                <span>&bull;</span>
                <span className="font-mono text-cyan-400">Status Server: Aktif HTTPS</span>
              </div>
            </div>
          </footer>

          {/* Engineering 3D CAD Docs Modal */}
          <EngineeringDocsModal
            isOpen={isDocsOpen}
            onClose={() => setIsDocsOpen(false)}
          />

          {/* Individual Telegram Modal from Overview */}
          {editingTelegramEws && (
            <TelegramConfigModal
              ews={editingTelegramEws}
              isOpen={true}
              onClose={() => setEditingTelegramEws(null)}
              onSave={(newCfg: TelegramConfig) => {
                handleUpdateEws({
                  ...editingTelegramEws,
                  telegramConfig: newCfg,
                });
                setEditingTelegramEws(null);
              }}
            />
          )}
        </>
      )}
    </div>
  );
}
