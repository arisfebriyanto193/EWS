import React, { useState } from 'react';
import { UserAccount } from '../types';
import { INITIAL_USERS } from '../mockData';
import { ShieldAlert, ShieldCheck, Lock, User, Radio, KeyRound, ChevronRight, Info } from 'lucide-react';

interface LoginModalProps {
  onLogin: (user: UserAccount) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('admin_bpbd');
  const [password, setPassword] = useState('ews123');
  const [error, setError] = useState('');
  const [selectedPresetId, setSelectedPresetId] = useState('user-01');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const matchedUser = INITIAL_USERS.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase()
    );

    if (matchedUser) {
      if (password.length >= 4) {
        onLogin(matchedUser);
      } else {
        setError('Kata sandi minimal 4 karakter (Gunakan "ews123" untuk demo)');
      }
    } else {
      setError('Pengguna tidak ditemukan. Silakan gunakan tombol Akses Cepat di bawah.');
    }
  };

  const handleSelectPreset = (user: UserAccount) => {
    setSelectedPresetId(user.id);
    setUsername(user.username);
    setPassword('ews123');
    setError('');
  };

  const handleQuickLogin = (user: UserAccount) => {
    onLogin(user);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl shadow-cyan-950/50 overflow-hidden grid grid-cols-1 lg:grid-cols-12 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Left hero / branding panel */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-slate-800 to-cyan-950 p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-700/80 relative overflow-hidden">
          <div className="absolute -top-16 -right-16 w-56 h-56 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold text-xl">
                <Radio className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
                  Dokumen Spesifikasi Teknis
                </span>
                <h1 className="text-lg font-bold text-white leading-tight">
                  Sistem EWS & Perangkap Hama
                </h1>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Sistem Web Monitoring 4 Titik Landslide Early Warning System (EWS), 5 Unit Perangkap Hama Bertenaga Surya, dan Notifikasi Mandiri Telegram Bot per Titik.
            </p>

            <div className="space-y-3">
              <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/60">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Autentikasi Hak Akses Peran Terenkripsi</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/60">
                <Radio className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Modem 4G LTE SIMCom A7670C & ESP32</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-slate-800/60 p-2.5 rounded-lg border border-slate-700/60">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Sirine Lokal 12V 110-120dB & Telegram Bot</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800/80 mt-6 text-xs text-slate-400 flex items-center justify-between">
            <span>Standar IP65 / VRLA 12V</span>
            <span className="font-mono text-cyan-400">Firmware v2.4.1</span>
          </div>
        </div>

        {/* Right login form panel */}
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-white">Masuk ke Sistem</h2>
                <p className="text-xs text-slate-400">
                  Pilih peran operator EWS atau login menggunakan kredensial
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-mono font-medium bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                Port 3000 HTTPS
              </span>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-950/60 border border-red-700/60 rounded-xl text-red-200 text-xs flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  ID Pengguna / Username
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Contoh: admin_bpbd atau operator_ews1"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5 flex justify-between">
                  <span>Kata Sandi (Password)</span>
                  <span className="text-[11px] text-cyan-400 font-normal">Default demo: ews123</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-mono"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-sm rounded-xl shadow-lg shadow-cyan-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                <span>Masuk ke Dashboard</span>
              </button>
            </form>

            {/* Quick role selector */}
            <div className="mt-6 pt-5 border-t border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-cyan-400" />
                  Pilih Cepat Akun Demo (1-Klik):
                </span>
                <span className="text-[10px] text-slate-400">Pilih & klik langsung</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                {INITIAL_USERS.map((user) => {
                  const isSelected = selectedPresetId === user.id;
                  const isEwsOp = user.role.startsWith('operator_');
                  return (
                    <div
                      key={user.id}
                      onClick={() => handleSelectPreset(user)}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between gap-2 group ${
                        isSelected
                          ? 'bg-cyan-950/70 border-cyan-500/80 ring-1 ring-cyan-500/40'
                          : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-medium truncate ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                            {user.fullName}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">
                          {isEwsOp ? `Akses Mandiri ${user.assignedEwsId}` : user.role === 'superadmin' ? 'Akses Penuh Semua EWS' : 'Akses Publik'}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleQuickLogin(user);
                        }}
                        className="px-2 py-1 bg-cyan-600/80 hover:bg-cyan-500 text-[11px] text-white rounded-lg shrink-0 transition-colors flex items-center gap-1"
                        title={`Masuk langsung sebagai ${user.fullName}`}
                      >
                        <span>Pilih</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 text-center">
            Pusat Data Mitigasi Bencana & Hama Pertanian Presisi &bull; Sertifikat SSL Aktif
          </div>
        </div>
      </div>
    </div>
  );
};
